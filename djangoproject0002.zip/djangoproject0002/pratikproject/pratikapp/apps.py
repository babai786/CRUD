from django.apps import AppConfig


class PratikappConfig(AppConfig):
    name = 'pratikapp'
